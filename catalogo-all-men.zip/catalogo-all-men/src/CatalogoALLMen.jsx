
export default function CatalogoALLMen() {
  const produtos = [
    {
      cor: "Branca",
      imagem: "/images/armani-branca.png",
    },
    {
      cor: "Preta",
      imagem: "/images/armani-preta.png",
    },
    {
      cor: "Verde Escuro",
      imagem: "/images/armani-verde-escuro.png",
    },
    {
      cor: "Verde Claro",
      imagem: "/images/armani-verde-claro.png",
    },
    {
      cor: "Bege",
      imagem: "/images/armani-bege.png",
    },
    {
      cor: "Laranja",
      imagem: "/images/armani-laranja.png",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-black to-neutral-800 text-white p-6">
      <h1 className="text-4xl font-bold text-center mb-8">Catálogo ALL Men</h1>
      <p className="text-center text-lg mb-12 max-w-xl mx-auto">
        Camisetas <span className="font-semibold">Armani</span> em diversas cores, com estampa silkada,
        tecido premium e caimento perfeito. Apenas <span className="text-green-400 font-bold">R$64,90</span>!
        Tamanhos do <span className="font-semibold">P ao GG</span>.
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {produtos.map((produto, index) => (
          <div
            key={index}
            className="bg-white text-black rounded-2xl shadow-lg overflow-hidden hover:scale-105 transition-all"
          >
            <img src={produto.imagem} alt={`Camiseta Armani ${produto.cor}`} className="w-full h-64 object-cover" />
            <div className="p-4">
              <h2 className="text-xl font-bold">Armani {produto.cor}</h2>
              <p className="text-sm text-neutral-600">Tecido premium | Estampa silkada</p>
              <p className="text-lg font-semibold mt-2">R$64,90</p>
              <p className="text-sm">Tamanhos: P, M, G, GG</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
