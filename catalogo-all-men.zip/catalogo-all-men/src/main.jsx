
import React from 'react';
import ReactDOM from 'react-dom/client';
import CatalogoALLMen from './CatalogoALLMen';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <CatalogoALLMen />
  </React.StrictMode>
);
